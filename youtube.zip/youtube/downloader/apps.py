from django.apps import AppConfig


class DownloaderConfig(AppConfig):
    name = 'downloader'
